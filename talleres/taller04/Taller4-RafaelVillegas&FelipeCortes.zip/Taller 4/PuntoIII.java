
/**
 * Write a description of class PuntoIII here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class PuntoIII
{
    public static void ordenar(int  [] nums){
       for (int i = 0; i<nums.length; i++) 
       {
         int j=i;
         while(j>0&&nums[j-1]>nums[j]){
             int temp = nums[j];
             nums[j] = nums[j-1];
             nums[j-1] = temp;
             j = j-1;
             try{
           TimeUnit.MILLISECONDS.sleep(1);
         }
         catch(Exception e)
         {
         }
            }
        }
 }
    
   public static int[] generarArregloDeTamanoN(int n){
  int[] array = new int[n];
  for (int i =0; i<n; i++)
     array[i] = n-i;
  return array;
}

public static void main(String[] args){
  for(int i = 1; i <= 100; i = i + 1)
    System.out.println(i+" "+tomarTiempo(i));
}

public static long tomarTiempo(int n){
  int[] a = generarArregloDeTamanoN(n);
  long startTime = System.currentTimeMillis();
  ordenar(a);
  long estimatedTime = System.currentTimeMillis() - startTime;
  return estimatedTime;
}
}
