
/**
 * Write a description of class PuntoII here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class PuntoII
{
    public static void tablasMultiplicar(int n){
       
       for (int i = 0; i<=n; i++) 
       {
       for(int j=0; j<=n; j++){
         System.out.println(i+"*"+j+"="+i*j);
         try{
           TimeUnit.MILLISECONDS.sleep(10);
         }
         catch(Exception e){
            }
        }
 }
}
    public static int generarN(){
  int max = 100;
  Random generator = new Random();
  int num=generator.nextInt(max);
  return num;
}

public static void main(String[] args){
  int i=generarN();
  System.out.println(i+" "+tomarTiempo(i));
}

public static long tomarTiempo(int n){
  long startTime = System.currentTimeMillis();
  tablasMultiplicar(n);
  long estimatedTime = System.currentTimeMillis() - startTime;
  return estimatedTime;
}
}
